﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FoolGame
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            if (keyData == Keys.Space)
            {
                Form3 notfool = new Form3();
                this.Hide();
                notfool.Show();
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        int m = 0;
        private void button2_mouseEnter(object sender, EventArgs e)
        {
            Random n = new Random();
            m++;
            Point point = new Point(
            int.Parse(n.Next(700).ToString()),
            int.Parse(n.Next(400).ToString())
            );
            button2.Location = point;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.Tag = this;
            f2.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }
    }
}
